 Author: Viral R. Galaiya & Nathan Dasilva 
Student #s: 44944149 and 25840142
 CS Accounts: x1y9a and o9v9a
 Date: 2015/11/22

"We have read and understood the plagiarism policies at https://www.cs.ubc.ca/our-department/administration/policies/collaboration 
and we understand that no excuse for plagiarism will be accepted, including any listed in http://www.cs.ubc.ca/~tmm/courses/cheat.html"

We used breakpoints to check the value of the variables and confirmed that they alligned with what was required.

We had a lot of memory errors and we used the debugger to see what the problem was.

We spent about 7 hours each working on the lab.

We are each responsible for about 50% of the assigment.